<?php
    class Pepper {
        
    }

?>