<?php
    class Order {
        public $pepper_id;
        public $first_name;
        public $last_name;
        public $credit_card;
        public $address;
        public $phone;
        public $zip_code;
        public $state;
        public $quantity;
        public $ship;
    }

?>